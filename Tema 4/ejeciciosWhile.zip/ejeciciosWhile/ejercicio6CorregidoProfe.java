public class ejercicio6CorregidoProfe {
    public static void main(String[] args) {
        
        int numero;
        int temporal;
        int digitos=1;

        System.out.println("\033[1MNÚMERO DE DÍGIOS DE UN NUMERO\033[0M");
        System.out.print("Introdicce un numero entero:");
        numero=Integer.parseInt(System.console().readLine());



    }
}
