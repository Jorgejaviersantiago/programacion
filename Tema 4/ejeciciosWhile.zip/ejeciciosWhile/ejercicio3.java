public class ejercicio3 {
    public static void main(String[] args) {
    int num=0;        
        do{
            System.out.print(" "+num);
            num+=5;
        }while(num<=100);{
           
        }
    }
}
