public class ejercicio2 {
    public static void main(String[] args) {
        
        int num=0;

        while (num<=100) {
            System.out.print(" "+num);
            num+=5;
        }











    }
}
